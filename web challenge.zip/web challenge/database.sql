DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    secret TEXT NOT NULL
);

INSERT INTO users (username, password, secret) VALUES ('admin', 'supersecurepassword', 'AxP25{Eclipse_DataErasedByFemto}');
INSERT INTO users (username, password, secret) VALUES ('user', 'userpass', 'No flag for you');
