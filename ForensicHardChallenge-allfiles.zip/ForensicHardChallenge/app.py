from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import sqlite3
import os
import re

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Ensure database is initialized
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()  # Initialize DB

# Password validation function
def is_valid_password(password):
    pattern = r"^[A-Z][0-9][a-zA-Z]{2}[\W_]$"  # 1st: Capital, 2nd: Number, 3rd & 4th: Letter, 5th: Special char
    return bool(re.match(pattern, password))

@app.route('/')
def index():
    return render_template('index.html', username=session.get('username'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()

        if user:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            flash("Invalid Credentials! Try again.", "error")

    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if not is_valid_password(password):
            flash("""Password must:\n 
                  > Be exactly 5 characters long.\n
                  > Start with a capital letter.\n
                  > Second character must be a number.\n
                  > Third and fourth characters must be letters.\n
                  > End with a special character.""", "error")
            return render_template('signup.html')

        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            conn.close()
            flash("Successfully created a new user.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username already exists! Choose another one.", "error")
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# Serve the Flag.zip file
@app.route('/Forbidden/Flag.zip')
def serve_flag():
    return send_from_directory(
        r'/app/Forbidden', 
        'Flag.zip', 
        as_attachment=True  # Forces file download
    )

# Serve m4lW4r3.exe outside Forbidden folder
@app.route('/m4lW4r3.exe')
def serve_hidden2():
    return send_from_directory(os.getcwd(), 'm4lW4r3.exe', as_attachment=True)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)

